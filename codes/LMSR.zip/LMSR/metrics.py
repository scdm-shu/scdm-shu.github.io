import numpy as np


def precision(real_apis, pred_apis):
    """
    计算精确度（Precision）
    Precision = |realAPIs ∩ predAPIs| / |predAPIs|
    """
    if len(pred_apis) == 0:
        return 0
    hit_set = set(real_apis) & set(pred_apis)
    return len(hit_set) / len(pred_apis)


def recall(real_apis, pred_apis):
    """
    计算召回率（Recall）
    Recall = |realAPIs ∩ predAPIs| / |realAPIs|
    """
    if len(real_apis) == 0:
        return 0
    hit_set = set(real_apis) & set(pred_apis)
    return len(hit_set) / len(real_apis)


def ndcg(real_apis, pred_apis):
    """
    计算归一化折损累计增益（NDCG）
    NDCG = DCG / IDCG
    """
    if len(real_apis) == 0:
        return 0

    # 计算 DCG
    dcg = sum([1.0 / np.log2(i + 2) for i, api in enumerate(pred_apis) if api in real_apis])

    # 计算 IDCG
    idcg = sum([1.0 / np.log2(i + 2) for i in range(min(len(real_apis), len(pred_apis)))])

    return dcg / idcg if idcg > 0 else 0


def mean_average_precision(real_apis, pred_apis):
    """
    计算平均精度（Mean Average Precision, MAP）
    """
    hits = 0
    sum_precision = 0
    for i, pred in enumerate(pred_apis, start=1):
        if pred in real_apis:
            hits += 1
            sum_precision += hits / i
    return sum_precision / len(real_apis) if hits > 0 else 0


class Metric:
    """
    评价指标类，用于批量计算 Precision, Recall, NDCG 和 MAP
    """

    def __init__(self, pred_list=[5, 10, 15, 20]):
        """初始化评价指标类"""
        self.pred_list = pred_list
        self.reset()

    def reset(self):
        """重置各项指标"""
        self.Precision = np.zeros(len(self.pred_list))
        self.Recall = np.zeros(len(self.pred_list))
        self.NDCG = np.zeros(len(self.pred_list))
        self.MAP = np.zeros(len(self.pred_list))
        self.count = 0

    def update(self, batch_target, batch_pred, is_rag=False):
        """更新指标"""
        if batch_target.dim() == 1:
            batch_target = batch_target.unsqueeze(0)
            batch_pred = batch_pred.unsqueeze(0)
        batch_size = batch_target.size(0)

        for target, pred in zip(batch_target, batch_pred):
            target = target.nonzero().squeeze().tolist() if not is_rag else target.squeeze().tolist()
            if isinstance(target, int):
                target = [target]
            if not is_rag:
              pred = pred.argsort(descending=True).tolist()
            else:
                pred = pred.squeeze().tolist()
            
            if isinstance(pred, int):
                pred = [pred]

            for i, k in enumerate(self.pred_list):
                self.Precision[i] += precision(target, pred[:k])
                self.Recall[i] += recall(target, pred[:k])
                self.NDCG[i] += ndcg(target, pred[:k])
                self.MAP[i] += mean_average_precision(target, pred[:k])

        self.count += batch_size

    def compute(self):
        """计算最终的各项指标"""
        self.Precision /= self.count
        self.Recall /= self.count
        self.NDCG /= self.count
        self.MAP /= self.count
        return {
            "Precision": self.Precision,
            "Recall": self.Recall,
            "NDCG": self.NDCG,
            "MAP": self.MAP
        }
