import json
from transformers import AutoModel, LlamaTokenizerFast, TrainingArguments, BitsAndBytesConfig, AutoModelForSequenceClassification
from datasets import Dataset, DatasetDict
import torch
from peft import get_peft_model, LoraConfig
import os
import torch.nn as nn
from torch.optim import AdamW
from torch.nn import BCEWithLogitsLoss
from tqdm import tqdm
import logging
from datetime import datetime
from metrics import Metric

def get_logger(log_type):
    """
    获取日志记录器
    
    Args:
        log_type (str): 日志类型，如'train'或'test'
        
    Returns:
        logging.Logger: 配置好的日志记录器
    """
    # 创建日志目录
    log_dir = os.path.join('./logs', log_type)
    os.makedirs(log_dir, exist_ok=True)
    
    # 生成日志文件名
    timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    file_name = f"{log_type.replace('/', '_')}_{timestamp}.log"
    log_path = os.path.join(log_dir, file_name)
    
    # 创建logger
    logger = logging.getLogger(f'api_recommendation_{log_type}')
    
    # 如果logger已经有处理器，说明已经被初始化过，直接返回
    if logger.handlers:
        return logger
        
    # 设置日志级别
    logger.setLevel(logging.INFO)
    
    # 创建文件处理器
    file_handler = logging.FileHandler(log_path)
    file_handler.setLevel(logging.INFO)
    
    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # 创建格式器
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 设置格式器
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    # 添加处理器
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    # 记录初始信息
    logger.info(f"Started logging to {log_path}")
    logger.info(f"Log type: {log_type}")
    
    return logger


def get_model_params(model):
    """
    计算模型的总参数量和可训练参数量

    Args:
        model (nn.Module): PyTorch 模型

    Returns:
        tuple: (总参数量, 可训练参数量)
    """
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total_params, trainable_params


# Disable P2P and IB for RTX 4000 series
os.environ["NCCL_P2P_DISABLE"] = "1"
os.environ["NCCL_IB_DISABLE"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"


# Load and preprocess the dataset
def load_and_preprocess_data(file_path, batch_size=32):
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Extract the 'label' field and create one-hot encoded labels
    num_classes = 1342
    dataset = []

    # Read mashup.csv to get mashup descriptions
    import pandas as pd
    mashup_df = pd.read_csv('data/processed/mashup.csv')
    
    # Add mashup_description to each item in data by index order
    for i, item in enumerate(data):
        if i < len(mashup_df):
            item['original_description'] = mashup_df.iloc[i]['mashup_description']
        else:
            item['original_description'] = ""  # Default empty string if index out of range
    
    for item in data:
        one_hot_label = [0] * num_classes
        for index in item['label']:
            one_hot_label[index] = 1
        # labels.append(one_hot_label)
        dataset.append({'text': item['enhanced_description'], 'labels': one_hot_label})
    
    # random.seed(2023)
    # shuffle(dataset)
    
    # Create a dataset
    # dataset = Dataset.from_dict({'text': descriptions, 'labels': labels})
    
    # Split the dataset into train and test sets
    dataset = Dataset.from_list(dataset)
    train_test_valid_split = dataset.train_test_split(test_size=0.4, shuffle=True, seed=2023)
    test_valid_split = train_test_valid_split['test'].train_test_split(test_size=0.2, shuffle=True, seed=2023)
    train_dataset = train_test_valid_split['train']
    test_dataset = test_valid_split['train']
    valid_dataset = test_valid_split['test']
    # train_dataset, test_dataset = dataset.train_test_split(test_size=train_test_split_ratio).values()
    # Save the test set to a JSON file
    # test_dataset.to_json('PWDataset/test_dataset_ori_text.json', orient='records', lines=True)
    
    return DatasetDict({'train': train_dataset, 'test': test_dataset, 'val': valid_dataset})

# Define the LLM class
class LLMFinetuner(nn.Module):
    def __init__(self, model_name, num_labels):
        super().__init__()
        self.tokenizer = LlamaTokenizerFast.from_pretrained(model_name, local_files_only=True)
        
        # Set the padding token
        if self.tokenizer.pad_token is None:
            self.tokenizer.add_special_tokens({'pad_token': '[PAD]'})
        
        quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.bfloat16,
            )

        attn_implementation = "flash_attention_2"

        # Load the pre-trained model
        self.base_model = AutoModel.from_pretrained(
            model_name,
            quantization_config=quantization_config,
            attn_implementation=attn_implementation,
            device_map="auto",
            num_labels=num_labels,
            local_files_only=True
        )
        self.classifier = torch.nn.Linear(self.base_model.config.hidden_size, num_labels).to(self.base_model.device)

        # Configure LoRA
        lora_config = LoraConfig(
            r=8,
            lora_alpha=16,
            lora_dropout=0.1,
            target_modules=["q_proj", "v_proj", "k_proj", "o_proj"]
        )
        
        # Apply LoRA to the model
        self.base_model = get_peft_model(self.base_model, lora_config)

    def tokenize_function(self, examples):
        return self.tokenizer(examples['text'], max_length=700, padding=True, truncation=True)
    
    def prepare_inputs(self, input):
        """
        Prepare inputs for the model by replacing special token embeddings with corresponding features.

        Args:
            input_ids (torch.Tensor): Input token IDs.
            attention_mask (torch.Tensor): Attention mask for input tokens.
            special_features (dict): Dictionary containing special features for each special token.

        Returns:
            dict: A dictionary containing prepared inputs for the model.
        """
        # Replace special token embeddings
        inputs_embeds = self.base_model.get_input_embeddings()(input['input_ids'])
        attention_mask = input['attention_mask']

        return {
            "inputs_embeds": inputs_embeds,
            "attention_mask": attention_mask
        }
    
    def forward(self, **kwargs):
        # Tokenize
        # tokenized = self.tokenizer(kwargs['input'], max_length=700, padding=True, truncation=True)
        # input_ids = torch.tensor(tokenized.input_ids).to(self.base_model.device)
        # attention_mask = torch.tensor(tokenized.attention_mask).to(self.base_model.device)
        # Prepare inputs
        kwargs['input']['input_ids'].to(self.base_model.device)
        kwargs['input']['attention_mask'].to(self.base_model.device)

        inputs = self.prepare_inputs(kwargs['input'])
        inputs['inputs_embeds'].to(self.base_model.device)
        # print("Attention mask values:", inputs['attention_mask'])
        # Forward pass
        outputs = self.base_model(**inputs, output_hidden_states=False)
        last_token_hidden_state = outputs[0][:, -1, :]
        last_token_hidden_state = last_token_hidden_state.to(self.classifier.weight.dtype)        # print(last_token_hidden_state.shape)
        return self.classifier(last_token_hidden_state)
        
# Load and preprocess the dataset
# dataset = load_and_preprocess_data('../data/processed/enhanced_mashup_dataset_10_api.json')

# Initialize and train the LLM
# llm_finetuner = LLMFinetuner('meta-llama/Meta-Llama-3.1-8B-Instruct', num_labels=1009)

def train_llm_finetuner(output_dir, batch_size, epochs):
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    '''
    meta-llama/Meta-Llama-3.1-8B-Instruct
    meta-llama/Llama-2-7b-hf
    meta-llama/Llama-3.2-3B
    '''

    model = LLMFinetuner('meta-llama/Llama-3.2-3B', num_labels=1342)
    model.train()
    
    # Load and preprocess the dataset
    dataset = load_and_preprocess_data('data/PWDataset/enhanced_mashup_dataset_2_api_new.json')

    train_dataset = dataset['train'].map(model.tokenize_function)
    train_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    train_dataloader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

    # Validation dataset
    val_dataset = dataset['val'].map(model.tokenize_function)
    val_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    val_dataloader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    # Set up optimizer and loss function
    optimizer = AdamW(model.parameters(), lr=2e-5, weight_decay=0.01)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=2, verbose=True)
    criterion = BCEWithLogitsLoss()

    # Training loop with early stopping
    best_loss = float('inf')
    best_model_path = None
    patience = 5
    patience_counter = 0
    # logger = get_logger('recommendation_train_3b/ori_text')
    logger = get_logger('recommendation_train_3b')

    total_params, trainable_params = get_model_params(model)
    logger.info(f'Total parameters: {total_params}')
    logger.info(f'Trainable parameters: {trainable_params}')


    for epoch in tqdm(range(epochs), desc="Training Progress"):
        epoch_loss = 0.0
        model.train()
        print(f"Epoch {epoch} - Training Begin")
        for batch in tqdm(train_dataloader, desc="Batch Progress"):
            optimizer.zero_grad()
            batch = {k: v.to(model.base_model.device) for k, v in batch.items()}
            batch['labels'] = batch['labels'].float()

            # Forward pass
            outputs = model(input=batch)
            loss = criterion(outputs, batch['labels'])
            epoch_loss += loss.item()

            # Backward pass and optimization
            loss.backward()
            optimizer.step()

        avg_epoch_loss = epoch_loss / len(dataset['train'])
        scheduler.step(avg_epoch_loss)
        print(f"Epoch {epoch} - Finished - Training Loss: {avg_epoch_loss}")

        # Validation phase
        model.eval()
        print(f"Epoch {epoch} - Validation Begin")
        metric = Metric([1, 3, 5, 10])
        val_loss = 0.0
        correct_top5 = 0
        total_samples = 0
        with torch.no_grad():
            for batch in tqdm(val_dataloader, desc="Validation Progress"):
                batch = {k: v.to(model.base_model.device) for k, v in batch.items()}
                batch['labels'] = batch['labels'].float()
                outputs = model(input=batch)
                loss = criterion(outputs, batch['labels'])
                val_loss += loss.item()
                metric.update(batch['labels'], outputs)

                # _, pred = outputs.topk(5, dim=1)

        avg_val_loss = val_loss / len(dataset['val'])
        eval_result = metric.compute()
        _print_eval_info(avg_val_loss, eval_result, logger)
        print(f"Epoch {epoch} - Finished - Validation Loss: {avg_val_loss}")


        if avg_val_loss < best_loss:
            best_loss = avg_val_loss
            best_model_path = f"{output_dir}/best_model_lora_3b_2_api_0109"
            torch.save(model.state_dict(), best_model_path)
            patience_counter = 0
        else:
            patience_counter += 1

        if patience_counter >= patience:
            print(f"Early stopping triggered at epoch {epoch}")
            break
    
    print(f"Best model saved at: {best_model_path} with loss: {best_loss}")

def _print_eval_info(loss, eval_result, logger):
    loss_info = f'[testing] Loss: {loss:.6f}'
    metric_info = f'Precision: {eval_result["Precision"].round(6)}\n' \
                  f'Recall:    {eval_result["Recall"].round(6)}\n' \
                  f'MAP:       {eval_result["MAP"].round(6)}\n' \
                  f'NDCG:      {eval_result["NDCG"].round(6)}'

    logger.info(loss_info)
    logger.info(f'{metric_info}')
    

def evaluate_model(model_path, test_data_path):
    # Load the best model
    model = LLMFinetuner(model_name='meta-llama/Llama-3.2-3B', num_labels=1342)
    # Load the state dictionary
    state_dict = torch.load(model_path)
    
    # Filter out unexpected keys
    filtered_state_dict = {k: v for k, v in state_dict.items() if k in model.state_dict()}
    model.load_state_dict(filtered_state_dict, strict=False)
    model.eval()

    # Load the test dataset
    test_dataset = Dataset.from_json(test_data_path)
    test_dataset = test_dataset.map(model.tokenize_function)
    test_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    test_dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=1, shuffle=False)

    # Define the criterion
    criterion = BCEWithLogitsLoss()

    # Initialize metrics
    test_loss = 0.0
    metric = Metric()
    logger = get_logger('recommendation_test_7b/ori_text')


    with torch.no_grad():
        for batch in tqdm(test_dataloader, desc="Test Progress"):
            batch = {k: v.to(model.base_model.device) for k, v in batch.items()}
            batch['labels'] = batch['labels'].float()
            outputs = model(input=batch)
            loss = criterion(outputs, batch['labels'])
            test_loss += loss.item()
            metric.update(batch['labels'], outputs)

    avg_test_loss = test_loss / len(test_dataset)
    eval_result = metric.compute()
    _print_eval_info(avg_test_loss, eval_result, logger)

# Example usage
# evaluate_model(model_path='output/PWDataset/Recommendation/best_model_lora_3b_2_api_new', test_data_path='PWDataset/test_dataset_2_relevant_api_new.json')


# Example usage
train_llm_finetuner(output_dir='output/PWDataset/Recommendation/0109', batch_size=1, epochs=15)

# load_and_preprocess_data('data/PWDataset/enhanced_mashup_dataset_3_api.json')


