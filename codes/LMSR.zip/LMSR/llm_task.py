import json
import random
from transformers import AutoModel, LlamaTokenizerFast, TrainingArguments, BitsAndBytesConfig, AutoModelForSequenceClassification
from datasets import Dataset, DatasetDict
import torch
from peft import get_peft_model, LoraConfig
import os
import torch.nn as nn
from torch.optim import AdamW
from torch.nn import BCEWithLogitsLoss
from tqdm import tqdm
import logging
from datetime import datetime
from metrics import Metric
import sys
import os
from torch.nn.utils.rnn import pad_sequence
from diff_attn import DifferentialTransformer

from moe import MixtureOfExperts

def get_logger(log_type):
    """
    获取日志记录器
    
    Args:
        log_type (str): 日志类型，如'train'或'test'
        
    Returns:
        logging.Logger: 配置好的日志记录器
    """
    # 创建日志目录
    log_dir = os.path.join('./logs/mashup_cls', log_type)
    os.makedirs(log_dir, exist_ok=True)
    
    # 生成日志文件名
    timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    file_name = f"{log_type}_{timestamp}.log"
    log_path = os.path.join(log_dir, file_name)
    
    # 创建logger
    logger = logging.getLogger(f'api_recommendation_{log_type}')
    
    # 如果logger已经有处理器，说明已经被初始化过，直接返回
    if logger.handlers:
        return logger
        
    # 设置日志级别
    logger.setLevel(logging.INFO)
    
    # 创建文件处理器
    file_handler = logging.FileHandler(log_path)
    file_handler.setLevel(logging.INFO)
    
    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # 创建格式器
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 设置格式器
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    # 添加处理器
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    # 记录初始信息
    logger.info(f"Started logging to {log_path}")
    logger.info(f"Log type: {log_type}")
    
    return logger


# Disable P2P and IB for RTX 4000 series
os.environ["NCCL_P2P_DISABLE"] = "1"
os.environ["NCCL_IB_DISABLE"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "1"


# Load and preprocess the dataset
def load_and_preprocess_data(file_path, api_path='', batch_size=32):
    api_data = None
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if api_path:
        with open(api_path, 'r', encoding='utf-8') as f:
            api_data = json.load(f)
    
    # Extract the 'label' field and create one-hot encoded labels
    # num_classes = 1342
    num_classes = 443
    dataset = []
    for item in data:
        one_hot_label = [0] * num_classes
        # for index in item['mashup_used_api_id']:
        for index in item['category_id']:
            one_hot_label[index] = 1
        # labels.append(one_hot_label)
        dataset.append({'text': item['mashup_description'], 'labels': one_hot_label})
        # dataset.append({'text': item['api_description'], 'labels': one_hot_label})
    
    # random.seed(2023)
    # shuffle(dataset)
    
    # Create a dataset
    # dataset = Dataset.from_dict({'text': descriptions, 'labels': labels})
    
    # Split the dataset into train and test sets
    dataset = Dataset.from_list(dataset)
    train_test_valid_split = dataset.train_test_split(test_size=0.3, shuffle=True, seed=2023)
    test_valid_split = train_test_valid_split['test'].train_test_split(test_size=0.2, shuffle=True, seed=2023)
    train_dataset = train_test_valid_split['train']
    # test_dataset = test_valid_split['test']
    valid_dataset = test_valid_split['train']
    # train_dataset, test_dataset = dataset.train_test_split(test_size=train_test_split_ratio).values()
    # Save the test set to a JSON file
    # test_dataset.to_json('PWDataset/test_mashup_cls.json', orient='records', lines=True)
    if api_data:
        for item in api_data:
            one_hot_label = [0] * num_classes
            for index in item['category_id']:
                one_hot_label[index] = 1
            train_dataset.append({'text': item['api_description'], 'labels': one_hot_label, 'cate': 1}, )
        random.seed(2023)
        random.shuffle(train_dataset)
    
    return DatasetDict({'train': train_dataset, 'val': valid_dataset})
    # return DatasetDict({'test': dataset}), data

# Define the LLM class
class LLMTask(nn.Module):
    def __init__(self, model_name, num_labels):
        super().__init__()
        self.tokenizer = LlamaTokenizerFast.from_pretrained(model_name, local_files_only=True)
        
        # Set the padding token
        if self.tokenizer.pad_token is None:
            self.tokenizer.add_special_tokens({'pad_token': '[PAD]'})

        quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.bfloat16,
            )

        attn_implementation = "flash_attention_2"

        # Load the pre-trained model with gradient computation disabled
        self.base_model = AutoModel.from_pretrained(
            model_name,
            device_map="auto",
            quantization_config=quantization_config,
            attn_implementation=attn_implementation,
            num_labels=num_labels,
            local_files_only=True
        )
        
        # Freeze the base model parameters
        for param in self.base_model.parameters():
            param.requires_grad = False

        # Initialize MoE classifier
        hidden_size = self.base_model.config.hidden_size
        self.attn = DifferentialTransformer(hidden_size, 2).to(self.base_model.device)
        expert_hidden_size = hidden_size // 2
        # Create a stack of 10 MoE layers with normalization
        self.moe = nn.ModuleList([
            nn.Sequential(
                MixtureOfExperts(
                    input_size=hidden_size,
                    hidden_size=expert_hidden_size,
                    output_size=hidden_size,  # Each MoE maintains same input/output dimensions
                    num_specific_experts=2,
                    dropout_rate=0.1
                ),
                nn.LayerNorm(hidden_size)  # Normalize outputs between MoE layers
            ).to(self.base_model.device)
            for _ in range(3)
        ])
        
        # 添加全连接分类层
        self.classifier = nn.Linear(hidden_size, num_labels).to(self.base_model.device)

    def tokenize_function(self, examples):
        return self.tokenizer(examples['text'], max_length=700, padding=True, truncation=True)
    
    def prepare_inputs(self, input):
        """
        Prepare inputs for the model by replacing special token embeddings with corresponding features.

        Args:
            input_ids (torch.Tensor): Input token IDs.
            attention_mask (torch.Tensor): Attention mask for input tokens.
            special_features (dict): Dictionary containing special features for each special token.

        Returns:
            dict: A dictionary containing prepared inputs for the model.
        """
        # Replace special token embeddings
        with torch.no_grad():
            inputs_embeds = self.base_model.get_input_embeddings()(input['input_ids'])
        attention_mask = input['attention_mask']

        return {
            "inputs_embeds": inputs_embeds,
            "attention_mask": attention_mask
        }
    
    def forward(self, **kwargs):
        # 正确地将输入移动到设备上
        input_dict = kwargs['input']
        input_dict['input_ids'] = input_dict['input_ids'].to(self.base_model.device)
        input_dict['attention_mask'] = input_dict['attention_mask'].to(self.base_model.device)

        inputs = self.prepare_inputs(input_dict)
        inputs['inputs_embeds'] = inputs['inputs_embeds'].to(self.base_model.device)

        # Forward pass through frozen base model
        with torch.no_grad():
            outputs = self.base_model(**inputs, output_hidden_states=False)
            last_token_hidden_state = outputs[0].to(self.classifier.weight.dtype)
            last_token_hidden_state = self.attn(last_token_hidden_state)
        
        # Forward through stack of MoE layers
        x = last_token_hidden_state[:, -1, :]  # 取最后一个token的隐藏层状态
        for moe_layer in self.moe:
            x = moe_layer(x)  # Each layer is a Sequential containing MoE and LayerNorm
        
        # Forward through classifier
        return self.classifier(x)
        
# Load and preprocess the dataset
# dataset = load_and_preprocess_data('../data/processed/enhanced_mashup_dataset_10_api.json')

# Initialize and train the LLM
# llm_finetuner = LLMFinetuner('meta-llama/Meta-Llama-3.1-8B-Instruct', num_labels=1009)

def collate_fn(batch):
    """
    自定义的collate函数，用于处理不同长度的序列
    
    Args:
        batch: 一个包含字典的列表，每个字典包含'input_ids', 'attention_mask', 'labels'等字段
        
    Returns:
        一个字典，包含已经填充的张量
    """
    # 分离batch中的不同字段
    input_ids = [item['input_ids'] for item in batch]
    attention_mask = [item['attention_mask'] for item in batch]
    labels = torch.stack([item['labels'] for item in batch])
    
    # 对序列进行填充
    input_ids = pad_sequence(input_ids, batch_first=True, padding_value=0)
    attention_mask = pad_sequence(attention_mask, batch_first=True, padding_value=0)
    
    return {
        'input_ids': input_ids,
        'attention_mask': attention_mask,
        'labels': labels
    }

def train_llm_task(output_dir, batch_size, epochs):
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    '''
    meta-llama/Meta-Llama-3.1-8B-Instruct
    meta-llama/Llama-2-7b-hf
    meta-llama/Llama-3.2-3B
    '''

    # model = LLMTask('meta-llama/Meta-Llama-3.1-8B-Instruct', num_labels=1342)
    model = LLMTask('meta-llama/Meta-Llama-3.1-8B-Instruct', num_labels=443)
    # Load model parameters from saved checkpoint
    # checkpoint_path = 'output/PWDataset/classification/best_model_lora_8b_similar_mashup'
    # if os.path.exists(checkpoint_path):
    #     checkpoint = torch.load(checkpoint_path)
    #     # Load parameters except classifier layer
    #     model_dict = model.state_dict()
    #     pretrained_dict = {k: v for k, v in checkpoint.items() if 'classifier' not in k and k in model.state_dict()}
    #     model_dict.update(pretrained_dict)
    #     model.load_state_dict(model_dict, strict=False)
    #     print(f"Loaded model parameters from {checkpoint_path}")
    # else:
    #     print(f"No checkpoint found at {checkpoint_path}, starting from scratch")
    model.train()
    
    # Load and preprocess the dataset
    dataset = load_and_preprocess_data('data/PWDataset/mashup_processed_with_category_id_with_relationships.json')
    # dataset = load_and_preprocess_data('data/PWDataset/api_llm_processed_with_category_id.json')
    train_dataset = dataset['train'].map(model.tokenize_function)
    train_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    train_dataloader = torch.utils.data.DataLoader(
        train_dataset, 
        batch_size=batch_size, 
        shuffle=True,
        collate_fn=collate_fn  # 添加自定义的collate函数
    )

    # Validation dataset
    val_dataset = dataset['val'].map(model.tokenize_function)
    val_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    val_dataloader = torch.utils.data.DataLoader(
        val_dataset, 
        batch_size=batch_size, 
        shuffle=False,
        collate_fn=collate_fn  # 添加自定义的collate函数
    )

    # Set up optimizer and loss function
    optimizer = AdamW(model.parameters(), lr=2e-6, weight_decay=0.01)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=5, verbose=True)
    criterion = BCEWithLogitsLoss()

    # Training loop with early stopping
    best_loss = float('inf')
    best_model_path = None
    patience = 5
    patience_counter = 0
    logger = get_logger('train')



    for epoch in tqdm(range(epochs), desc="Training Progress"):
        epoch_loss = 0.0
        model.train()
        for batch in tqdm(train_dataloader, desc="Batch Progress"):
            optimizer.zero_grad()
            batch = {k: v.to(model.base_model.device) for k, v in batch.items()}
            batch['labels'] = batch['labels'].float()

            # Forward pass
            outputs = model(input=batch)
            loss = criterion(outputs, batch['labels'])
            epoch_loss += loss.item()

            # Backward pass and optimization
            loss.backward()
            optimizer.step()

        avg_epoch_loss = epoch_loss / len(dataset['train'])
        scheduler.step(avg_epoch_loss)
        print(f"Epoch {epoch} - Training Loss: {avg_epoch_loss}")

        # Validation phase
        model.eval()
        metric = Metric([1,3,5,10])
        val_loss = 0.0
        with torch.no_grad():
            for batch in tqdm(val_dataloader, desc="Validation Progress"):
                batch = {k: v.to(model.base_model.device) for k, v in batch.items()}
                batch['labels'] = batch['labels'].float()
                outputs = model(input=batch)
                loss = criterion(outputs, batch['labels'])
                val_loss += loss.item()
                metric.update(batch['labels'], outputs)

        avg_val_loss = val_loss / len(dataset['val'])
        # print(f"Epoch {epoch} - Validation Loss: {avg_val_loss}")
        eval_result = metric.compute()
        _print_eval_info(avg_val_loss, eval_result, logger)

        if avg_val_loss < best_loss:
            best_loss = avg_val_loss
            best_model_path = f"{output_dir}/best_model_lora_8b_mashup_cls_no_checkpoint"
            torch.save(model.state_dict(), best_model_path)
            patience_counter = 0
        else:
            patience_counter += 1

        if patience_counter >= patience:
            print(f"Early stopping triggered at epoch {epoch}")
            break
    
    print(f"Best model saved at: {best_model_path} with loss: {best_loss}")

def _print_eval_info(loss, eval_result, logger=None):
    loss_info = f'[testing] Loss: {loss:.6f}'
    metric_info = f'Precision: {eval_result["Precision"].round(6)}\n' \
                  f'Recall:    {eval_result["Recall"].round(6)}\n' \
                  f'MAP:       {eval_result["MAP"].round(6)}\n' \
                  f'NDCG:      {eval_result["NDCG"].round(6)}'

    if logger:
      logger.info(loss_info)
      logger.info(f'{metric_info}')
    

def evaluate_model(model_path, test_data_path=None):

    model = LLMTask(
        model_name='meta-llama/Meta-Llama-3.1-8B-Instruct', 
        num_labels=443
    )
    
    # Load the state dictionary with weights_only=True to avoid pickle security warning
    state_dict = torch.load(model_path, weights_only=True)
    
    # Filter out unexpected keys
    filtered_state_dict = {k: v for k, v in state_dict.items() if k in model.state_dict()}
    model.load_state_dict(filtered_state_dict, strict=False)
    model.eval()

    # 清理不需要的缓存
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    # dataset, json_data = load_and_preprocess_data('data/PWDataset/mashup_with_used_api_id_processed.json')

    # test_dataset = dataset['test'].map(model.tokenize_function)
    # test_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    # test_dataloader = torch.utils.data.DataLoader(
    #     test_dataset, 
    #     batch_size=2, 
    #     shuffle=False,
    #     collate_fn=collate_fn  # 添加自定义的collate函数
    # )

    # # Load the test dataset
    test_dataset = Dataset.from_json(test_data_path)
    
    # 过滤掉 cate=0 的项
    # test_dataset = test_dataset.filter(lambda x: x['cate'] == 1)
    
    test_dataset = test_dataset.map(model.tokenize_function)
    test_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    
    # 使用较小的batch_size并启用pin_memory
    test_dataloader = torch.utils.data.DataLoader(
        test_dataset, 
        batch_size=1,  # 使用较小的batch size
        shuffle=False,
        collate_fn=collate_fn,
        pin_memory=True  # 启用pin_memory以加速数据传输
    )

    # Define the criterion
    criterion = BCEWithLogitsLoss()

    # Initialize metrics
    test_loss = 0.0
    metric = Metric()
    logger = get_logger('test')
    
    # 跟踪当前处理的样本索引
    current_idx = 0

    with torch.no_grad():
        for batch in tqdm(test_dataloader, desc="Test Progress"):
            # 确保数据被正确地移动到GPU
            batch = {k: v.to(model.base_model.device, non_blocking=True) for k, v in batch.items()}
            batch['labels'] = batch['labels'].float()
            
            # 前向传播
            outputs = model(input=batch)
            loss = criterion(outputs, batch['labels'])
            # Get top 10 predicted API indices for each sample
            # top_k_values, top_k_indices = torch.topk(outputs, k=10, dim=1, largest=True)
            
            # Convert indices to CPU and numpy for storage
            # top_k_indices = top_k_indices.cpu().numpy()
            
            # Add related_apis to the current batch samples
            # for i, indices in enumerate(top_k_indices):
            #     # 计算当前样本的实际索引
            #     sample_idx = current_idx + i
            #     # Add predicted related APIs to the dataset
            #     json_data[sample_idx]['related_apis'] = indices.tolist()

            test_loss += loss.item()
            metric.update(batch['labels'], outputs)
            
            # 更新当前处理的样本索引
            current_idx += len(batch['input_ids'])
            
            # 每个batch后清理缓存
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    avg_test_loss = test_loss / len(test_dataset)
    eval_result = metric.compute()
    # Save the test dataset with predictions to a JSON file
    # with open('data/PWDataset/mashup_with_related_apis.json', 'w', encoding='utf-8') as f:
    #     json.dump(json_data, f, indent=4, ensure_ascii=False)
    _print_eval_info(avg_test_loss, eval_result, logger)

# Example usage
evaluate_model(model_path='./output/PWDataset/classification/mashup_cls/best_model_lora_8b_mashup_cls_no_checkpoint', test_data_path='PWDataset/test_mashup_cls.json')


# Example usage
# train_llm_task(output_dir='./output/PWDataset/classification/mashup_cls', batch_size=2, epochs=50)


