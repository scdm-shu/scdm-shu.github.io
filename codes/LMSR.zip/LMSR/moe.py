import torch
import torch.nn as nn
import torch.nn.functional as F

class Expert(nn.Module):
    """
    专家网络
    每个专家都是一个前馈神经网络，负责处理特定类型的任务
    """
    def __init__(self, input_size, hidden_size, output_size, dropout_rate=0.1):
        """
        初始化专家网络
        
        Args:
            input_size (int): 输入特征维度
            hidden_size (int): 隐藏层维度
            output_size (int): 输出维度（类别数量）
            dropout_rate (float): dropout比率
        """
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.GELU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_size, output_size)
        )
    
    def forward(self, x):
        return self.network(x)

class MixtureOfExperts(nn.Module):
    """
    混合专家模型
    包含一个通用专家和多个专有任务专家，以及一个用于选择专家的门控网络
    """
    def __init__(self, input_size, hidden_size, output_size, num_specific_experts=4, dropout_rate=0.1):
        """
        初始化混合专家模型
        
        Args:
            input_size (int): 输入特征维度
            hidden_size (int): 专家网络的隐藏层维度
            output_size (int): 输出维度（类别数量）
            num_specific_experts (int): 专有任务专家的数量
            dropout_rate (float): dropout比率
        """
        super().__init__()
        
        # 创建通用专家
        self.general_expert = Expert(input_size, hidden_size, output_size, dropout_rate)
        
        # 创建专有任务专家
        self.specific_experts = nn.ModuleList([
            Expert(input_size, hidden_size, output_size, dropout_rate)
            for _ in range(num_specific_experts)
        ])
        
        # 门控网络
        # 输出维度为专家数量+1（包括通用专家）
        self.gate = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.GELU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_size, num_specific_experts + 1)
        )
        
        self.num_experts = num_specific_experts + 1
        
    def forward(self, x):
        """
        前向传播函数
        
        Args:
            x (torch.Tensor): 输入特征，形状为 (batch_size, input_size)
            
        Returns:
            torch.Tensor: 混合输出，形状为 (batch_size, output_size)
        """
        # 计算门控权重
        gate_outputs = self.gate(x)
        gate_weights = F.softmax(gate_outputs, dim=-1)  # (batch_size, num_experts)
        
        # 获取每个专家的输出
        expert_outputs = []
        
        # 通用专家的输出
        general_output = self.general_expert(x)
        expert_outputs.append(general_output.unsqueeze(1))  # 添加专家维度
        
        # 专有任务专家的输出
        for expert in self.specific_experts:
            expert_output = expert(x)
            expert_outputs.append(expert_output.unsqueeze(1))
        
        # 将所有专家的输出堆叠在一起
        expert_outputs = torch.cat(expert_outputs, dim=1)  # (batch_size, num_experts, output_size)
        
        # 使用门控权重进行加权组合
        gate_weights = gate_weights.unsqueeze(-1)  # (batch_size, num_experts, 1)
        weighted_outputs = expert_outputs * gate_weights  # (batch_size, num_experts, output_size)
        
        # 合并所有专家的输出
        final_output = weighted_outputs.sum(dim=1)  # (batch_size, output_size)
        
        return final_output
